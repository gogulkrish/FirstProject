import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footwears',
  templateUrl: './footwears.component.html',
  styleUrls: ['./footwears.component.css']
})
export class FootwearsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
