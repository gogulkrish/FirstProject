import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tdydeals',
  templateUrl: './tdydeals.component.html',
  styleUrls: ['./tdydeals.component.css']
})
export class TdydealsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
