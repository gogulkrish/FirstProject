import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spimg',
  templateUrl: './spimg.component.html',
  styleUrls: ['./spimg.component.css']
})
export class SpimgComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
