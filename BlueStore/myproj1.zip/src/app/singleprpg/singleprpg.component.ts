import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-singleprpg',
  templateUrl: './singleprpg.component.html',
  styleUrls: ['./singleprpg.component.css']
})
export class SingleprpgComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
