import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topdeals',
  templateUrl: './topdeals.component.html',
  styleUrls: ['./topdeals.component.css']
})
export class TopdealsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
