import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brnddir',
  templateUrl: './brnddir.component.html',
  styleUrls: ['./brnddir.component.css']
})
export class BrnddirComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
