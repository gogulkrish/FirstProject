import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  myacnt="My Account"
  myorder="My Order"
  myshbag="My Shopping bag"
  mywishlst="My Wishlist"

  cntus="Contact Us"
  faq="FAQ"
  tandc="T&C"
  termuse="Terms of use"
  trakorder="Track Orders"
  shipng="Shipping"
  cancltion="Cancellation"
  retrn="Returns"
  prvcyplcy="Privacy Policy"
  
  constructor() { }

  ngOnInit(): void {
  }

}
