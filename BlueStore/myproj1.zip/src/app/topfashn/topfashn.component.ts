import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topfashn',
  templateUrl: './topfashn.component.html',
  styleUrls: ['./topfashn.component.css']
})
export class TopfashnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
